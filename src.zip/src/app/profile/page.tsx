import React from 'react';

const ProfilePage = () => {
  return (
    <main className="p-6">
      <h1 className="text-2xl font-bold">Profile Page</h1>
      <p>Welcome to your profile!</p>
    </main>
  );
};

export default ProfilePage;
